# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.0.x   | :white_check_mark: |
| 0.0.1   | :x:                |

<br/>

## Reporting a Vulnerability

Email: [tony@hotmail.com](mailto:tony.hlp@hotmail.com)
