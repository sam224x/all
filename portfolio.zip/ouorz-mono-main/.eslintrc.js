module.exports = {
	root: true,
	extends: ['@ouorz/eslint-config-root'],
	settings: {
		next: {
			rootDir: ['apps/*/'],
		},
	},
}
