module.exports = {
	root: true,
	extends: ['@ouorz/eslint-config-next'],
	rules: {
		camelcase: 'off',
	},
}
