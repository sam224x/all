import type { RootState } from ".."

const selectKbar = (state: RootState) => state.kbar

export { selectKbar }
