import type { RootState } from ".."

const selectGeneral = (state: RootState) => state.general

export { selectGeneral }
