import type { RootState } from ".."

const selectReader = (state: RootState) => state.reader

export { selectReader }
