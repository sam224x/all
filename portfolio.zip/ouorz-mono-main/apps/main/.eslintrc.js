module.exports = {
	root: true,
	extends: ["@ouorz/eslint-config-next"],
}
