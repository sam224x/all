# `ouorz-mono` Apps

<br/>

- `analytics`: Self-hosted Umami webite analytics service
- `interface`: Web 3 blog admin interface (WIP)
- `main`: Blog front-end
- `wordpress`: Blog custom WordPress theme
